<?php

include "bd/conexao.php";

@$conn->query("update p_apagar_pix set pago = '2'   where registro_apagar = $_GET[pedido] ");


	
?>

