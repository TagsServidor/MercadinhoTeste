

<?php include "head.php";?>
	
	
	<div class="row">
		
		 
		<div class="col-4"> 
		<div class="card" >
 <div class="card-body text-center" >
    <h5 class="card-title text-center" >O que você achou do nosso processo de compra?</h5>
  <span style="font-size:40px">&#128525;</span>   <span style="font-size:40px">&#128521;</span>
 <span style="font-size:40px">&#128533;</span>   <span style="font-size:40px">&#128532;</span>
    
  </div>
</div>
			</div>
			
				<div class="col-4"> 
		<div class="card" >
  <div class="card-body text-center" >
    <h5 class="card-title text-center" >O que você achou dso nossos preços?</h5>
  <span style="font-size:40px">&#128525;</span>   <span style="font-size:40px">&#128521;</span>
 <span style="font-size:40px">&#128533;</span>   <span style="font-size:40px">&#128532;</span>
    
  </div>
</div>
			</div>
		
		<div class="col-4"> 
		<div class="card" >
 <div class="card-body text-center" >
    <h5 class="card-title text-center" >Recomendaria o MERCADINHO para algum amigo?</h5>
  <span style="font-size:40px">&#128525;</span>   <span style="font-size:40px">&#128521;</span>
 <span style="font-size:40px">&#128533;</span>   <span style="font-size:40px">&#128532;</span>
    
  </div>
</div>
			</div>