

<!DOCTYPE html>
<html lang="pt-BR">

<head>

<title>Mercadinho</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/fonts/font-awesome/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">
<link href="estilo.css" rel="stylesheet" type="text/css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" >

	 <link rel="stylesheet" href="keyboard/Keyboard.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	
	
    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPoppins:400,500,700,800,900%7CRoboto:100,300,400,400i,500,700">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/css/skins/default.css">
<body style="background:transparent">

</head>

		<div class="col-12"> 
		<div class="card" >
 <div class="card-body text-center" >
    <h5 class="card-title text-center" >Recomendaria o MERCADINHO para algum amigo?</h5>
  <span style="font-size:40px">&#128525;</span>   <span style="font-size:40px">&#128521;</span>
 <span style="font-size:40px">&#128533;</span>   <span style="font-size:40px">&#128532;</span>
    
  </div>
</div>