
<html>
<head>
</head>
<body>
<form action="valida_cpf.php" method="post" name="cpf" id="cpf">
  CPF: 
  <label>
  <input name="cpf" type="text" id="cpf" size="14" maxlength="14">
  </label>
  <label>
  <input name="btvalidar" type="submit" id="btvalidar" value="  Validar  ">
  </label>
</form>
</body>
</html>

