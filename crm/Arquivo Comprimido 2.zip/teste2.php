
<?php

echo $_POST['minimo']
	?>sasas