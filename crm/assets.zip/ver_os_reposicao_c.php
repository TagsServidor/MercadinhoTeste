<?php @session_start();
if (!empty($_SESSION['id'])) {
} else {
    $_SESSION['msg'] = "Área restrita";
    header("Location: logar.php");
}
include "bd/conexao.php";
?>
<div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">OS &gt; <?php echo $_POST['os'] ?></h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                           
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                      
                        
                    </div> 
               
					
                <div class="container-fluid">
					<div class="row">
                            <div class="col-12">
                                <div class="card">
					                 <div class="card-body">
                                        <h4 class="card-title">Relação de produtos</h4>
                                        
										 
										 
										 
										 
										 
										    <div class="table-rep-plugin">
                                            <div class="table-responsive mb-0">
                                                <table id="tech-companies-1" class="table">
                                                    <thead>
                                                    <tr>
                                                        <th>Produto</th>
                                                        <th data-priority="1">QTD</th>
                                                        <th data-priority="3">Lote</th>
                                                       
                                                        <th data-priority="3">Ação</th>
                                                      </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
														
														<?php // LISTANDO OS EM ABERTO
														
$sqlosp = "SELECT * FROM os_produtos o2 inner join produtos p on o2.os_produtos_produto = p.id_produto  where o2.os_produtos_os  = '$_POST[os]' and o2.os_produtos_status ='2'  ";
$resultadoosp  = mysqli_query($conn, $sqlosp);
$totalosp  = mysqli_num_rows($resultadoosp);
if ($totalosp == 0) { 
?> <br>
																OS sem produtos
																
																
																<?php 

} else {  ?>
																
																

                                                
														
														
													<?php

while($linhaos  = mysqli_fetch_array($resultadoosp )){
	
 ?>                  
   


   
</div>
			<script>
												
var i = setInterval(function () {
    clearInterval(i);

    
    document.getElementById("loading<?php echo $linhaos['os_produtos_id'] ?>").style.display = "none";
    document.getElementById("content<?php echo $linhaos['os_produtos_id'] ?>").style.display = "block";
   
}, 2000);
													
													</script>											
														
                                                        <th><?php echo $linhaos['produto_nome'] ?>  <span class="co-name"> </span></th>
                                                        <td><?php echo $linhaos['os_produtos_qtd'] ?> </td>
                                                        <td><?php echo $linhaos['os_produtos_lote'] ?></td>
                                                        
                                                        <td>
															
															<div id="dvConteudo2<?php echo $linhaos['os_produtos_id'] ?>">
															
														  <img src="assets/images/checkp.gif" width="30" height="30" alt=""/> </div>
															
															
															<div id="dvConteudo3<?php echo $linhaos['os_produtos_id'] ?>" class="spinner" style="display: none">
																
																
																
																
																	 
															
                                                               <img src="assets/images/checkp.gif" /> 
                                                            
															</div>
														</td>
														
														
														
														
														
														
													
                                                      </tr>
													
														
														
														
			<script>
															
															 $(document).ready(function() {
 
	 $("#formos2<?php echo $linhaos['os_produtos_id'] ?>").submit(function(){
		 
		 
		 
		 var dados = jQuery( this ).serialize();
		 
		$.ajax({
			url: 'atualizar_os_produtos.php',
			cache: false,
			data: dados,
			type: "POST",  

			success: function(msg){
				
				$("#results2<?php echo $linhaos['os_produtos_id'] ?>").empty();
				$("#results2<?php echo $linhaos['os_produtos_id'] ?>").append(msg);
				document.getElementById("dvConteudo2<?php echo $linhaos['os_produtos_id'] ?>").style.display = "none";
				document.getElementById("dvConteudo3<?php echo $linhaos['os_produtos_id'] ?>").style.display = "block";


				
				
				
			}
			
		});
		 
		 return false;
	 });
 
 });
														</script>											
														
														
														
														<?php }} ?>
														
														  <!-- Fim lista os aberto  -->
                                                                                           
                                                    </tbody>
                                                </table>
                                            </div>
        
                                 
										 </div>
										
										  

                                  </div> </div> </div> </div> <div align="center"> <a href="os_concluidas" class="btn btn-success"> Voltar para OS  </a> </div>