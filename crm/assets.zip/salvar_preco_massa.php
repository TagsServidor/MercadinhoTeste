 <?php @session_start();
include "bd/conexao.php";

// ALTERANDO NAS UNIDADES
@$conn->query("update produtos_unidades set produto_unidade_valor =  '$_POST[valor]' where produto_unidade_produto  = '$_POST[produto]' ");

// ALTERANDO NAS ENTRADAS
@$conn->query("update entrada_produtos set entrada_venda =  '$_POST[valor]' where entrada_produto  = '$_POST[produto]'  order by id_entrada DESC ");



	
?>


