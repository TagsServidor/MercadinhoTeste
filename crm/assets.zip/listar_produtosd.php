<?php // listando em um box os instrutores
include "bd/conexao.php";

														
$sqlosp = "SELECT * FROM produtos_unidades pu inner join produtos p on pu.produto_unidade_produto = p.id_produto   where pu.produto_unidade_maximo >  pu.produto_unidade_estoque and pu.produto_unidade_unidade = $_POST[unidade]";
$resultadoosp  = mysqli_query($conn, $sqlosp);


$sqlos = "SELECT * FROM os_reposicao where os_unidade =  $_POST[unidade] and os_reposicao_tipo ='2' and os_status = '1' ";
$resultadoos  = mysqli_query($conn, $sqlos);
$linhaos  = mysqli_fetch_array($resultadoos);
$totalos = mysqli_num_rows($resultadoos );
?>
<!-- Sweet Alert-->
        <link href="assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />


<link href="assets/js/select2.min.css" rel="stylesheet" />
    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/select2.min.js"></script>
<br>
<?php if ($totalos >= '1' ) { ?> 

<div class="alert alert-danger" role="alert">
                                                Atenção não é permitido abrir outra OS de LISTA para essa central, já existe uma OS aberta, clique aqui para conferir.
                                                </div>

<?php } else { ?>
<h4>Lista atual de reposição: </h4>

<form id="geraros" method="post" action="#"> 
  <div class="table-rep-plugin">
                                            <div class="table-responsive mb-0">
                                                <table id="tech-companies-1" class="table">
                                                    <thead>
                                                    <tr>
                                                        <th>Produto</th>
                                                        <th data-priority="1">Estoque Atual</th>
                                                        <th data-priority="3">Estoque Minimo</th>
                                                       <th data-priority="3">Estoque Máximo</th>
														<th data-priority="3">Valor venda</th>
														<th data-priority="3">QTD Repor</th>
                                                        <th data-priority="3">Repor</th>
														<th data-priority="3">Estoque Central</th>
                                                      </tr>
                                                    </thead>
													
                                                    <tbody>
														
                                                    <tr>
														
<?php // LISTANDO OS EM ABERTO

while($linhaos  = mysqli_fetch_array($resultadoosp )){

$repor = $linhaos['produto_unidade_maximo'] - $linhaos['produto_unidade_estoque'] ;

$sqlec = "SELECT * FROM produtos_central where central_produto =  $linhaos[produto_unidade_produto] ";
$resultadoec  = mysqli_query($conn, $sqlec);
$linhaec  = mysqli_fetch_array($resultadoec);
	
$sqlep = "SELECT * FROM entrada_produtos where entrada_produto =  $linhaos[produto_unidade_produto] and entrada_status='2' order by entrada_data desc   ";
$resultadoep  = mysqli_query($conn, $sqlep);
$linhaep  = mysqli_fetch_array($resultadoep);
	
 ?>      
														
														
														     <!-- Center Modal example -->
                                                <div class="modal fade bs-example-modal-center<?php echo $linhaos['id_produto_unidades'] ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">ATENÇÃO!!!!</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div align="center"> <h5><strong>A quantidade a repor para este produto é maior que o estoque da CENTRAL</strong></h5> Para evitar quebra de estoque o sistema realizou o ajuste necessário na quantidade a repor. 
																</div>	
                                                            </div>
                                                        </div><!-- /.modal-content -->
                                                    </div><!-- /.modal-dialog -->
                                                </div><!-- /.modal -->
  
		                                                <th>
															
															
																
																<?php echo $linhaos['produto_nome'] ?> 
															
														
														
														</th>
														
														
														
														
														
														
                                                        <td><?php echo $linhaos['produto_unidade_estoque'] ?> </td>
                                                        <td><?php echo $linhaos['produto_unidade_minimo'] ?></td>
														<td><?php echo $linhaos['produto_unidade_maximo'] ?></td>
														<td><input name="valor[]" type="text" required="required" class="money form-control" style="width: 105px" value="<?php echo $linhaep['entrada_venda'] ?>"></td>
														
														 <td>
															 <?php echo $repor ?> 
															 <?php if($repor > $linhaec['central_produto_estoque']) { ?>                                                  <button type="button" class="btn btn-danger btn-sm waves-effect waves-light" data-bs-toggle="modal" data-bs-target=".bs-example-modal-center<?php echo $linhaos['id_produto_unidades'] ?>"><i class="fa fa-exclamation-triangle" aria-hidden="true" style="color: $fff"></i>  Alerta!</button>
															 
<?php } ?></td>
													
															 <td>
															 <?php if($repor > $linhaec['central_produto_estoque']) { ?>	 <input name="repor[]" type="number" required="required" class="form-control" style="width: 65px" max="<?php echo $linhaec['central_produto_estoque']?>"  value="<?php echo $linhaec['central_produto_estoque']	  ?>">
																

														 <?php } else { ?>
																<input name="repor[]" type="number" required="required" class="form-control" style="width: 65px" max="<?php echo $linhaec['central_produto_estoque']?>" value="<?php echo $repor  ?>"> 
																 <?php } ?>
														
													  </td>
														<td><?php echo $linhaec['central_produto_estoque'] ?>
													
														
														<input type="hidden" name="unidade" value="<?php echo $_POST['unidade'] ?>">
														<input type="hidden" name="lote[]" value="<?php echo $linhaec['central_produto_lote'] ?>">
														<input type="hidden" name="vencimento[]" value="<?php echo $linhaec['central_produto_validade'] ?>">	
														<input type="hidden" name="custo[]" value="<?php echo $linhaep['entrada_unitario'] ?>">		
															
														<input type="hidden" name="minimo[]" value="<?php echo $linhaos['produto_unidade_minimo'] ?>">	
														<input type="hidden" name="maximo[]" value="<?php echo $linhaos['produto_unidade_maximo'] ?>">		
														<input type="hidden" name="repor2[]" value="<?php echo $repor ?>">		
															
														
														<input type="hidden" name="produtou[]" value="<?php echo $linhaos['id_produto_unidades'] ?>">
														<input type="hidden" name="produto[]" value="<?php echo $linhaos['produto_unidade_produto'] ?>">	 
																 
														<input type="hidden" name="central" value="<?php echo $_GET['central'] ?>">
														<input type="hidden" name="idprodutocentral[]" value="<?php echo $linhaec['id_produto_central'] ?>">	 
															
														 <?php if($repor > $linhaec['central_produto_estoque']) { ?> 
															
															<?php $amenos = $repor - $linhaec['central_produto_estoque'] ?>
															<input type="hidden" name="amenos[]" value="sim">  
															<input type="hidden" name="qtdamenos[]" value="<?php echo $amenos ?>">  
															
															<?php } else {  ?>	
															
															  <input type="hidden" name="amenos[]" value="nao">
															<input type="hidden" name="qtdamenos[]" value="0"> 
															
															<?php } ?>
														</td>	
														
														
													  </div>
														</td>
														
														
														
														
														
														
													
                                                      </tr>
													
														
<?php } ?>
	  
	
	 
														</tbody>
                                                </table>
                                            </div>
         <div align="center">  <input type="SUBMIT" class="btn btn-info"value="GERAR OS"></div>

                </form>                  
										 </div>
<div id="results"> </div>
<!-- JAVASCRIPT -->
        
<script>
	
	 $(document).ready(function() {
 
	 $("#geraros").submit(function(){
		 
		  $('html,body').animate({
        scrollTop: $("#results2").offset().top},
        'slow');
		 
		 var dados = jQuery( this ).serialize();
		 
		$.ajax({
			url: 'salvar_lista_os.php',
			cache: false,
			data: dados,
			type: "POST",  

			success: function(msg){
				
				$("#results").empty();
				$("#results").append(msg);
			}
			
		});
		 
		 return false;
	 });
 
 });



</script>
<?php } ?>

<script src="assets/js/jquery.mask.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/examples.js"></script>	