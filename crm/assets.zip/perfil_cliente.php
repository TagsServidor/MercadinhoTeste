<?php @session_start();
if (!empty($_SESSION['id'])) {
} else {
    $_SESSION['msg'] = "Área restrita";
    header("Location: logar.php");
}
include "bd/conexao.php";

/// CONECTANDO OS PRODUTOS

$sql = "SELECT * FROM clientes where id_cliente = $_POST[id] ";
$resultado = mysqli_query($conn, $sql);
$total = mysqli_num_rows($resultado);	
$linha = mysqli_fetch_array($resultado);

$sqluc = "SELECT * FROM pedidos where pedido_cliente = $_POST[id] order by pedido_data desc limit 10  ";
$resultadouc = mysqli_query($conn, $sqluc);
$totaluc = mysqli_num_rows($resultadouc);	

?>

<style>
	.esconderbarras {
		font-size: 0px;
	}

</style>
<script src="assets/js/jquery.js"></script>
 <script src="assets/js/form_estoqueentrada.js"></script>
 <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>


 <!-- Select com Busca-->
 <link href="assets/js/select2.min.css" rel="stylesheet" />
    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/select2.min.js"></script>

  <!-- Responsive Table css -->
        <link href="assets/libs/admin-resources/rwd-table/rwd-table.min.css" rel="stylesheet" type="text/css" />

<!-- DataTables -->
        <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />   
<div id="results"></div>
					
					<div id="dvConteudo" >

<div class="main-content">

                <div class="page-content">
<div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">Relatórios &gt; Clientes</h4> 

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                           
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                      
                        
                    </div> 
               
					
                <div class="container-fluid">
					
				  <div class="row mb-4">
                            <div class="col-xl-4">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <div class="text-center">
                                            <div class="dropdown float-end">
                                                <a class="text-body dropdown-toggle font-size-18" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true">
                                                  <i class="uil uil-ellipsis-v"></i>
                                                </a>
                                              
                                                
                                            </div>
                                            <div class="clearfix"></div>
                                            <div>
                                                <?php if($linha['cliente_foto'] =='') { } else { ?> <img src="../produtos/<?php echo $linha['cliente_foto'] ?>" alt="" class="avatar-xl rounded-circle "> <?php } ?>
                                            </div>
                                            <h5 class="mt-3 mb-1"><?php echo $linha['cliente_nome'] ?></h5>
                                             
											
											
											
                                           
                                      </div>

                                        <hr class="my-4">

                                        <div class="text-muted">
                                            <h5 class="font-size-16">Informações</h5>
                                           
                                            <div class="table-responsive mt-4">
                                                <div>
                                                    <p class="mb-1">Último acesso :</p>
                                                    <h5 class="font-size-16"></h5>
                                                </div>
                                                <div class="mt-4">
                                                    <p class="mb-1">QTD Pedidos:</p>
                                                    <h5 class="font-size-16"></h5>
                                                </div>
                                                <div class="mt-4">
                                                    <p class="mb-1">Valor gasto :</p>
                                                  
                                              </div>
                                                

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8">
                        <div class="row"><!-- end card-->
                        <div class="card">
                          <div class="card-body">
                            <div class="float-end">
                              <div class="dropdown"> <a class=" dropdown-toggle" href="#" id="dropdownMenuButton2"
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span class="text-muted">Ver todas <i class="fa fa-plus" aria-hidden="true"></i></span> </a> </div>
                            </div>
                            <h4 class="card-title mb-4">Últimas Compras</h4>
                            <div data-simplebar style="max-height: 336px;">
                              <div class="table-responsive">
                                <table class="table table-borderless table-centered table-nowrap">
                                  <tbody>
                                    <tr>                                    
                                    <tr>
                                      <th>Local</th>
                                      <th>Data</th>
                                      <th>Pedido</th>
                                      <th>Valor</th>
                                      <th>Status</th>
                                      <th>Ações</th>
                                    </tr>
                                  <tbody>
                                    <tr>
                                      <?php 
	while ($linhauc = mysqli_fetch_array($resultadouc)) {
															
			
															
															?>
                                      <td ><span style="width: 15px;">
                                        <?php if ($linhauc['pedido_local'] =='1') { ?>
                                        <img src="assets/images/avatar_toten.jpg" class="avatar-xs rounded-circle " alt="...">
                                        <?php } ?>
                                        <?php if ($linhauc['pedido_local'] =='2') { ?>
                                        <img src="assets/images/avatar_app.jpg" class="avatar-xs rounded-circle " alt="...">
                                        <?php } ?>
                                      </span></td>
                                      <td><h6 class="font-size-15 mb-1 fw-normal"><span style="width: 15px;"><?php echo date('d/m/Y', strtotime($linhauc['pedido_data'])); ?></span></h6></td>
                                      <td><h6 class="font-size-15 mb-1 fw-normal"><?php echo $linhauc['id_pedido'] ?></h6></td>
                                      <td><h6 class="font-size-15 mb-1 fw-normal">R$ <?php echo $linhauc['pedido_valor'] ?></h6></td>
                                      <td><h6 class="font-size-15 mb-1 fw-normal">
                                        <?php if ($linhauc['pedido_status'] =='2') { ?>
                                        <span class="btn btn-info btn-sm">Realizado </span>
                                        <?php } ?>
                                        <?php if ($linhauc['pedido_status'] =='3') { ?>
                                        <span class="btn btn-success btn-sm">Pag. Confirmado </span>
                                        <?php } ?>
                                        <?php if ($linhauc['pedido_status'] =='4') { ?>
                                        <span class="btn btn-danger btn-sm">Pag. Recusado </span>
                                        <?php } ?>
                                        <?php if ($linhauc['pedido_status'] =='5') { ?>
                                        <span class="btn btn-warning btn-sm">Abandonado </span>
                                        <?php } ?>
                                      </h6></td>
                                      <td ><i class="icon-xs icon me-2 text-success" data-feather="trending-up"></i><i class="icon-xs icon me-2 text-success" data-feather="trending-up"></i>+ detalhes</td>
                                    </tr>
                                    <?php } ?>
                                  </tbody>
                                </table>
                              </div>
                              <!-- enbd table-responsive-->
                            </div>
                            <!-- data-sidebar-->
                          </div>
                          <!-- end card-body-->
                        </div>
                        <!-- end col -->

					 <div class="col-xl-12">
			    <div class="col-xl-12">

	     <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
        <script src="assets/libs/jquery.counterup/jquery.counterup.min.js"></script>

        <!-- apexcharts -->
        <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>