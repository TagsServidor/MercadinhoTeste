<?php @session_start();
if (!empty($_SESSION['id'])) {
} else {
    $_SESSION['msg'] = "Área restrita";
    header("Location: logar.php");
}

/// CONECTANDO AOS PEDIDOS

$sql = "SELECT * FROM pedidos p LEFT JOIN unidades u on p.pedido_unidade = u.id_unidade   INNER JOIN condominios c on u.unidade_condominio = c.id_condominio 
 INNER JOIN clientes ci on p.pedido_cliente = ci.id_cliente where p.pedido_unidade = $id order by p.pedido_data  desc ";

$resultado = mysqli_query($conn, $sql);
$total = mysqli_num_rows($resultado);	



?>

<style>
	.esconderbarras {
		font-size: 0px;
	}

</style>
<script src="assets/js/jquery.js"></script>
 <script src="assets/js/form_estoqueentrada.js"></script>
 <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>


 <!-- Select com Busca-->
 <link href="assets/js/select2.min.css" rel="stylesheet" />
    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/select2.min.js"></script>

  <!-- Responsive Table css -->
        <link href="assets/libs/admin-resources/rwd-table/rwd-table.min.css" rel="stylesheet" type="text/css" />

<!-- DataTables -->
        <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />   

				


					<div id="dvConteudo" >

<div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">Financeiro &gt; Vendas</h4> 

                                    <div class="page-title-right">
										 
                                        <ol class="breadcrumb m-0">
                                           
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>
                      
                        
                    </div> 
               
					
					
					
					
					
					
                <div class="container-fluid">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Temos um total de (<?php echo $total ?>) vendas  registradas </h4><br>
                    
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                      <thead>
                        <tr>  
							<th>Pedido</th>
                          <th>Data</th>
							 <th>Unidade</th>
							 <th>Cliente</th>
                          <th>Valor</th>
                          <th>Status</th>
							 <th>Local</th>
                          <th>Ações</th>
                        
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
							
							
							<?php // LISTANDO OS EM ABERTO
														
while($linha = mysqli_fetch_array($resultado)){

	
	?>
							
	  <!--  Extra Large modal example -->
                                                <div class="modal fade bs-example-modal-xl<?php echo $linha['id_pedido']; ?>" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-xl">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="myExtraLargeModalLabel">Id venda: #<?php echo $linha['id_pedido']; ?> - Controle: <?php echo $linha['pedido_session']; ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
																
																<div align="center"> <?php if ($linha['pedido_status'] =='2') { ?> <button class="btn btn-success"> PAGO </button> <?php } ?> <?php if ($linha['pedido_status'] =='1') { ?> <button class="btn btn-info"> REALIZADO </button><?php } ?> <?php if ($linha['pedido_status'] =='3') { ?> <button class="btn btn-danger"> CANCELADO </button><?php } ?></div>
																<hr>
                                                                <strong>Data:</strong> <?php echo date('d/m/Y', strtotime($linha['pedido_data'])); ?>  <?php echo $linha['pedido_hora']; ?> - <strong>Unidade:</strong> <?php echo $linha['unidade_nome'] ?> <strong>Local:</strong> <?php if ($linha['pedido_local'] =='1') { ?> Terminal <?php } ?> <?php if ($linha['pedido_local'] =='2') { ?> APP <?php } ?> <br>
																 <strong>Cliente:</strong> <?php $linha['cliente_nome']  ?>  - <strong>CPF:</strong> <?php $linha['cliente_cpf']  ?> <strong>Telefone:</strong> <?php $linha['cliente_telefone']  ?> E-mail <?php $linha['cliente_email']  ?><br>
																
																
																
																
																<hr>
                                                             
																<?php
$sqli = "SELECT * FROM carrinho c INNER JOIN produtos p ON c.produto_carrinho = p.id_produto where c.session_carrinho = '$linha[pedido_session]' ";
$resultadoi = mysqli_query($conn, $sqli);
$totali = mysqli_num_rows($resultadoi);	

	?>
	   <h5>Pedido</h5>											
																
																<div class="row" style="background: #F2F2F2; padding: 5px"> 
																
																<div class="col-1"> <strong> QTD</strong> </div>
																<div class="col-5"> <strong>Item</strong> </div>
																<div class="col-3"> <strong>Valor Un. </strong></div>
																<div class="col-3"> <strong>Total</strong> </div>
																
																</div>
																
																<?php while($item = mysqli_fetch_array($resultadoi)){ ?>
															
																
															<div class="row"> 
																
																<div class="col-2"> <?php echo $item['qtd_carrinho'] ?> </div>
																<div class="col-4" ><?php echo $item['produto_nome'] ?>  </div>
																<div class="col-3"> <?php echo $item['preco_uni'] ?> </div>
																<div class="col-3"> <?php $vtotal =  $item['qtd_carrinho'] *  $item['preco_uni']; echo $vtotal; ?>  </div>
																<hr>
																</div>
																
																<?php } ?>
	
																
                                                            </div>
                                                        </div><!-- /.modal-content -->
                                                    </div><!-- /.modal-dialog -->
                                                </div><!-- /.modal -->						

							
							
							 <td><?php echo $linha['id_pedido']; ?> </td>
                          <td><?php echo date('d/m/Y', strtotime($linha['pedido_data'])); ?> </td>
					   <td><?php echo $linha['unidade_nome'] ?></td>
							 <td><?php echo $linha['cliente_nome'] ?></td>
                          <td>R$ <?php echo $linha['pedido_valor'] ?></td>
                          <td><?php if ($linha['pedido_status'] =='2') { ?>
                            <button class="btn btn-success"> PAGO </button>
                            <?php } ?>
                            <?php if (linha['pedido_status'] =='1') { ?>
                            <button class="btn btn-info"> REALIZADO </button>
                            <?php } ?>
                            <?php if ($linha['pedido_status'] =='3') { ?>
                            <button class="btn btn-danger"> CANCELADO </button>
                          <?php } ?></td>
							<td> <span style="width: 15px;">
  <?php if ($linha['pedido_local'] =='1') { ?>
  <img src="assets/images/avatar_toten.jpg" class="avatar-xs rounded-circle " alt="...">
  <?php } ?>
  <?php if ($linha['pedido_local'] =='2') { ?>
  <img src="assets/images/avatar_app.jpg" class="avatar-xs rounded-circle " alt="...">
  <?php } ?>
</span> </td>
	 <td><a href="#"  data-bs-toggle="modal" data-bs-target=".bs-example-modal-xl<?php echo $linha['id_pedido']; ?>"> + Detalhes</a></td>					
							
                         
                          
							
							
							
                        </tr>
						  
					<script>
															
															 $(document).ready(function() {
 
	 $("#formos<?php echo $linha['id_produto'] ?>").submit(function(){
		 
		 
		 
		 var dados = jQuery( this ).serialize();
		 
		$.ajax({
			url: 'perfil_produto.php',
			cache: false,
			data: dados,
			type: "POST",  

			success: function(msg){
				
				$("#results").empty();
				$("#results").append(msg);
				document.getElementById("dvConteudo").style.display = "none";
				

				
				
				
			}
			
		});
		 
		 return false;
	 });
 
 });
														</script>	  
						  	  
						  
						  
						  <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>   </div>   </div>   </div>   </div>
					
				<div id="results"></div>
					
					
			   <!-- JAVASCRIPT -->
       			
			   <!-- JAVASCRIPT -->
       	<script>
	
	$(document).ready(function () {
	
    $('#datatable').DataTable({
		
		buttons: [
        'copy', 'excel', 'pdf',
			
    ],
        order: [0, 'desc'],

    });
})
	
		

		
	</script>

        <!-- Required datatable js -->
        <script src="assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/jszip/jszip.min.js"></script>
        <script src="assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        
        <!-- Responsive examples -->
        <script src="assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="assets/js/pages/datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>		
					
         <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>
        <script src="assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script><!-- Init js -->
        <script src="assets/js/pages/table-responsive.init.js"></script><script src="assets/js/pages/table-responsive.init.js"></script><script src="assets/js/pages/table-responsive.init.js"></script>